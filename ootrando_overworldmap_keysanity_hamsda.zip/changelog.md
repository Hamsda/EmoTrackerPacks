# Changelog

## 2.0.1.5

- fixed DMC wall HP reachable without explosives
- removed item counts from dungeons
- fixed Zoras Domain shop as adult
- changed Forest Temple courtyard logic
- improved Fire Temple:
  - lift1 sequence breakable
  - better restrictions for Volvagia
- changed GTG maze chests into separate locations and added key requirements

## 2.0.1.4

- first version of keysanity pack:
  - reworked layouts to include small key counts and boss keys
  - added key requirements to dungeons