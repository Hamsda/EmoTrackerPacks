# Changelog

## 2.0.0.0

- first version of keysanity pack:
  - reworked layouts to include small key counts and boss keys
  - added key requirements to dungeons