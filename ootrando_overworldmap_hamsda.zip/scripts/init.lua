ScriptHost:LoadScript("scripts/user_settings.lua")
ScriptHost:LoadScript("scripts/globals.lua")
ScriptHost:LoadScript("scripts/cached_helpers.lua")

ScriptHost:LoadScript("scripts/load_items.lua")
ScriptHost:LoadScript("scripts/load_locations.lua")
ScriptHost:LoadScript("scripts/load_updaters.lua")
ScriptHost:LoadScript("scripts/load_layouts.lua")
