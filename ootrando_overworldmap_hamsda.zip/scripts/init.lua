Tracker:AddItems("items/common.json")
Tracker:AddItems("items/keys.json")

Tracker:AddMaps("maps/maps.json")

Tracker:AddLocations("locations/overworld.json")
Tracker:AddLocations("locations/dungeons.json")

Tracker:AddLayouts("layouts/tracker.json")
Tracker:AddLayouts("layouts/broadcast.json")